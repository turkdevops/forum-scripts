XMB 1.8 through 1.9.10 Upgrade Utility for XMB 1.9.11


IMPORTANT:  You must follow these steps in the correct order.
You must be logged in to your board before making any changes.
If you are not logged in you will be unable to use this utility.


Instructions

1. Disable your forums using the Board Status setting.

2. BACKUP YOUR DATABASE - This script cannot be undone!

 Did you backup everything? Including config.php? You'll need that.

3. Confirm your forum database account is granted ALTER, CREATE, INDEX, and LOCK privileges.

4. Copy your config.php settings into the new file.

5. Upload the XMB 1.9.11 files.  Do not upload the install folder (delete it if necessary).

6. Upload the upgrade directory to your board's root directory.

7. Run this script by hitting the upgrade URL, for example:  http://www.example.com/forum/upgrade/

8. When finished, remember to delete the upgrade directory and enable your forums using the Board Status setting.


If it doesn't work, back it out by restoring from backups, and come see us at

https://forums.xmbforum2.com/

Good luck!
XMBForum Team
